# Leistungsstarkes Game Framework

LGF (Leistungsstarkes Game Framework) 是一款基於陳偉凱老師的 Game Framework 加上些許功能的 Powerful Game Framework。

專案不保證長期維護，有任何問題或者任何其他想要的 feature，請丟 issue，祝使用愉快 :D



## 使用手冊與函式庫

你可以在這裡找到這份專案的使用手冊與函式庫。

| 資源 | 連結 |
| ---- | ---- |
| 使用手冊 | https://lgf-readthedocs.readthedocs.io/zh_TW/latest/index.html |
| 函式庫 | https://ntut-xuan.github.io/LeistungsstarkesGameFramework |



## 銘謝

謝謝 國立臺北科技大學 陳偉凱教授 開發了這個遊戲框架

並且謝謝 國立臺北科技大學 陳碩漢教授 同意這個框架能夠公開使用。
